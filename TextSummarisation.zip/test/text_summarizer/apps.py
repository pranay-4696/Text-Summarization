from django.apps import AppConfig


class TextSummarizerConfig(AppConfig):
    name = 'text_summarizer'
