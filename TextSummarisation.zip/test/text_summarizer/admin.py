from django.contrib import admin
from .models import PDFModel

admin.site.register(PDFModel)
# Register your models here.
